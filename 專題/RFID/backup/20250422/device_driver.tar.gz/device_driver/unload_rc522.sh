#!/bin/bash

# 移除設備節點（如果存在）
sudo rm -f /dev/rc522

# 卸載驅動模組
sudo rmmod rc522_kmod

echo "RC522 驅動與裝置節點已卸載"
