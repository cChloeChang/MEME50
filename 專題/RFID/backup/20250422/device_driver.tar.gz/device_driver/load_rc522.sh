#!/bin/bash

# 1. 移除舊模組
sudo rmmod rc522_kmod 2>/dev/null

# 2. 載入新模組
if ! sudo insmod ./rc522_kmod.ko; then
    echo "錯誤：模組載入失敗"
    exit 1
fi

# 3. 獲取 major number
major=$(awk "\$2==\"rc522_kmod\" {print \$1}" /proc/devices)
if [ -z "$major" ]; then
    echo "錯誤：無法取得 major number"
    exit 1
fi

# 4. 移除舊設備節點（如果存在）
sudo rm -f /dev/rc522 2>/dev/null

# 5. 創建設備節點並設定權限
sudo mknod /dev/rc522 c $major 0
sudo chmod 666 /dev/rc522

echo "裝置節點已建立：/dev/rc522"
