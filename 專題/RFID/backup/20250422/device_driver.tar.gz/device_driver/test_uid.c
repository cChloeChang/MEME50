#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>

int main() {
    int fd = open("/dev/rc522", O_RDONLY);
    if (fd < 0) {
        perror("無法開啟裝置");
        return 1;
    }

    uint8_t uid[4];
    ssize_t bytes = read(fd, uid, 4);
    
    if (bytes == 4) {
        printf("檢測到卡片 UID: %02X %02X %02X %02X\n", 
               uid[0], uid[1], uid[2], uid[3]);
    } else {
        printf("讀取失敗 (錯誤碼: %zd)\n", bytes);
    }

    close(fd);
    return 0;
}

