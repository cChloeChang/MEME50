// test_rc522_read.c
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main() {
    int fd;
    unsigned char uid[4];

    fd = open("/dev/rc522", O_RDONLY);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    int ret = read(fd, uid, sizeof(uid));
    if (ret < 0) {
        perror("read");
        close(fd);
        return 1;
    }

    printf("UID: %02X %02X %02X %02X\n", uid[0], uid[1], uid[2], uid[3]);
    close(fd);
    return 0;
}
