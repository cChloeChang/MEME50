#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/spi/spi.h>
#include <linux/gpio.h>
#include <linux/delay.h>
#include <linux/uaccess.h>

#define DRIVER_NAME "rc522_kmod"
#define RC522_SPI_SPEED 500000
#define RC522_RST_GPIO 25 // pin22

#define COMMAND_REG     0x01
#define FIFO_DATA_REG   0x09
#define FIFO_LEVEL_REG  0x0A
#define BIT_FRAMING_REG 0x0D

struct rc522_dev {
    struct spi_device *spi;
    struct cdev cdev;
    dev_t devno;
    u8 uid[4];
};

static struct rc522_dev *rc522_device;
static int major;
static struct class *rc522_class = NULL;
static struct device *rc522_device_file = NULL;

// SPI 寫入
static void rc522_write_reg(struct spi_device *spi, u8 reg, u8 value) {
    u8 tx_buf[2] = { (reg << 1) & 0x7E, value };
    struct spi_transfer t = {
        .tx_buf = tx_buf,
        .len = 2,
    };
    spi_sync_transfer(spi, &t, 1);
}

// SPI 讀取
static u8 rc522_read_reg(struct spi_device *spi, u8 reg) {
    u8 tx_buf[2] = { ((reg << 1) & 0x7E) | 0x80, 0 };
    u8 rx_buf[2];
    struct spi_transfer t = {
        .tx_buf = tx_buf,
        .rx_buf = rx_buf,
        .len = 2,
    };
    spi_sync_transfer(spi, &t, 1);
    return rx_buf[1];
}

// 讀 UID（簡化範例）
static int rc522_read_uid(struct spi_device *spi) {
    int i;
    rc522_write_reg(spi, COMMAND_REG, 0x0C); // Transceive
    rc522_write_reg(spi, FIFO_DATA_REG, 0x26); // REQIDL
    rc522_write_reg(spi, BIT_FRAMING_REG, 0x87);

    msleep(10);

    u8 fifo_len = rc522_read_reg(spi, FIFO_LEVEL_REG);
    if (fifo_len >= 4) {
        for (i = 0; i < 4; i++)
            rc522_device->uid[i] = rc522_read_reg(spi, FIFO_DATA_REG);
        return 0;
    }
    return -EIO;
}

// fops
static ssize_t rc522_read(struct file *filp, char __user *buf, size_t count, loff_t *pos) {
    if (rc522_read_uid(rc522_device->spi) == 0) {
        if (copy_to_user(buf, rc522_device->uid, 4) != 0)
            return -EFAULT;
        return 4;
    }
    return -EIO;
}
static int rc522_open(struct inode *inode, struct file *filp) {
    printk(KERN_INFO "RC522: Device opened\n"); 
    return 0; 
}

static int rc522_release(struct inode *inode, struct file *filp) { return 0; }
static struct file_operations rc522_fops = {
    .owner = THIS_MODULE,
    .read = rc522_read,
    .open = rc522_open,
    .release = rc522_release,
};

// SPI 驅動 probe/remove
static int rc522_probe(struct spi_device *spi) {
    int ret;
    rc522_device = kzalloc(sizeof(struct rc522_dev), GFP_KERNEL);
    if (!rc522_device) return -ENOMEM;

    rc522_device->spi = spi;
    cdev_init(&rc522_device->cdev, &rc522_fops);
    rc522_device->cdev.owner = THIS_MODULE;
    ret = cdev_add(&rc522_device->cdev, rc522_device->devno, 1);
    if (ret) {
        kfree(rc522_device);
        return ret;
    }
    return 0;
}
static void rc522_remove(struct spi_device *spi) {
    if (rc522_device) {
        cdev_del(&rc522_device->cdev);
        kfree(rc522_device);
    }
}

// SPI device ID
static const struct spi_device_id rc522_spi_ids[] = {
    { "rc522", 0 },
    { }
};
MODULE_DEVICE_TABLE(spi, rc522_spi_ids);

static struct spi_driver rc522_spi_driver = {
    .driver = {
        .name = DRIVER_NAME,
        .owner = THIS_MODULE,
    },
    .id_table = rc522_spi_ids,
    .probe = rc522_probe,
    .remove = rc522_remove,
};

// 核心模組初始化/卸載
static int __init rc522_init(void) {
    int ret;
    dev_t dev;

    // ================== 新增 GPIO 初始化 ==================
    // 請求 GPIO 資源（RC522_RST_GPIO 需與硬體接線一致，例如 GPIO25）
    if (gpio_request(RC522_RST_GPIO, "rc522_rst")) {
        printk(KERN_ERR "Failed to request GPIO %d\n", RC522_RST_GPIO);
        return -EBUSY;  // 返回 -EBUSY 表示 GPIO 已被佔用
    }

    // 設定 GPIO 為輸出模式，初始值為高電位（依模組規格書要求）
    gpio_direction_output(RC522_RST_GPIO, 1);
    // ======================================================

    // 動態分配 major number
    ret = alloc_chrdev_region(&dev, 0, 1, DRIVER_NAME);
    if (ret < 0) {
        gpio_free(RC522_RST_GPIO);  // 分配失敗時釋放 GPIO
        return ret;
    }
    major = MAJOR(dev);

    // 建立 class
    rc522_class = class_create(DRIVER_NAME);
    if (IS_ERR(rc522_class)) {
        gpio_free(RC522_RST_GPIO);
        unregister_chrdev_region(dev, 1);
        return PTR_ERR(rc522_class);
    }

    // 建立裝置節點
    rc522_device_file = device_create(rc522_class, NULL, dev, NULL, DRIVER_NAME);

    // 註冊 SPI 驅動
    ret = spi_register_driver(&rc522_spi_driver);
    if (ret < 0) {
        device_destroy(rc522_class, dev);
        class_destroy(rc522_class);
        gpio_free(RC522_RST_GPIO);
        unregister_chrdev_region(dev, 1);
        return ret;
    }

    printk(KERN_INFO "RC522: module loaded, major=%d\n", major);
    return 0;
}



static void __exit rc522_exit(void) {
    dev_t dev = MKDEV(major, 0);

    spi_unregister_driver(&rc522_spi_driver);
    device_destroy(rc522_class, dev);
    class_destroy(rc522_class);
    unregister_chrdev_region(dev, 1);

    // ================== 新增 GPIO 釋放 ==================
    gpio_free(RC522_RST_GPIO);
    // ====================================================
    
    printk(KERN_INFO "RC522: module unloaded\n");
}

module_init(rc522_init);
module_exit(rc522_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("RC522 RFID Reader Driver (no device tree)");
