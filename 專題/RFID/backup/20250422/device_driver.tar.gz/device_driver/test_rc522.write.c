// test_rc522_write.c
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main() {
    int fd;
    unsigned char data[4] = {0x0F, 0x01, 0x02, 0x03}; // 測試資料

    fd = open("/dev/rc522", O_WRONLY);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    int ret = write(fd, data, sizeof(data));
    if (ret < 0) {
        perror("write");
        close(fd);
        return 1;
    }

    printf("寫入成功 (%d bytes)\n", ret);
    close(fd);
    return 0;
}
