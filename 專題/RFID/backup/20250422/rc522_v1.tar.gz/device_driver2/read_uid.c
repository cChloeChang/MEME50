#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd = open("/dev/rc522", O_RDONLY);
    if (fd < 0) {
        perror("Failed to open /dev/rc522");
        return 1;
    }

    unsigned char uid[5];
    ssize_t ret = read(fd, uid, sizeof(uid));
    if (ret > 0) {
        printf("UID: ");
        for (int i = 0; i < ret; ++i)
            printf("%02X ", uid[i]);
        printf("\n");
    } else {
        printf("Failed to read UID\n");
    }

    close(fd);
    return 0;
}
