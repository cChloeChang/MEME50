#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/device.h>

#define DEVICE_NAME "rc522"
#define CLASS_NAME  "rc522class"

static dev_t dev_num;
static struct cdev rc522_cdev;
static struct class *rc522_class;
static struct device *rc522_device;

// 模擬的 UID 資料
static char fake_uid[5] = {0xDE, 0xAD, 0xBE, 0xEF, 0x01};

static int rc522_open(struct inode *inode, struct file *file) {
    printk(KERN_INFO "[rc522] device opened\n");
    return 0;
}

static ssize_t rc522_read(struct file *file, char __user *buf, size_t len, loff_t *offset) {
    size_t data_len = sizeof(fake_uid);
    if (*offset >= data_len)
        return 0;

    if (len > data_len - *offset)
        len = data_len - *offset;

    if (copy_to_user(buf, fake_uid + *offset, len))
        return -EFAULT;

    *offset += len;
    printk(KERN_INFO "[rc522] read UID\n");
    return len;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = rc522_open,
    .read = rc522_read,
};

static int __init rc522_init(void) {
    alloc_chrdev_region(&dev_num, 0, 1, DEVICE_NAME);
    cdev_init(&rc522_cdev, &fops);
    cdev_add(&rc522_cdev, dev_num, 1);

    rc522_class = class_create(CLASS_NAME);
    rc522_device = device_create(rc522_class, NULL, dev_num, NULL, DEVICE_NAME);

    printk(KERN_INFO "[rc522] module loaded\n");
    return 0;
}

static void __exit rc522_exit(void) {
    device_destroy(rc522_class, dev_num);
    class_destroy(rc522_class);
    cdev_del(&rc522_cdev);
    unregister_chrdev_region(dev_num, 1);
    printk(KERN_INFO "[rc522] module unloaded\n");
}

module_init(rc522_init);
module_exit(rc522_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Simple RC522 kernel module");
