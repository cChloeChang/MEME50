#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>

int main() {
    int fd = open("/dev/rc522", O_RDWR);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    // 測試寫入（範例指令）
    uint8_t cmd = 0x0F;
    if (write(fd, &cmd, 1) != 1) {
        perror("write");
        close(fd);
        return 1;
    }

    // 測試讀取
    uint8_t val = 0;
    if (read(fd, &val, 1) != 1) {
        perror("read");
        close(fd);
        return 1;
    }

    printf("Read value: 0x%02X\n", val);

    close(fd);
    return 0;
}

