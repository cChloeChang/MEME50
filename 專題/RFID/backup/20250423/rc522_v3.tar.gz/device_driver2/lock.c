#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

#define FIFO_PATH "/tmp/smart_lock_fifo"
#define DEVICE_PATH "/dev/rc522"

int main(void) {
    int fifo_fd, dev_fd;
    char uid_buf[16]; // 最多 4 bytes UID + '\0'

    // 建立 FIFO
    mkfifo(FIFO_PATH, 0666);
    fifo_fd = open(FIFO_PATH, O_WRONLY | O_NONBLOCK);
    if (fifo_fd < 0) {
        perror("無法開啟 FIFO 進行寫入");
        exit(1);
    }

    // 開啟 /dev/rc522（你寫的 kernel driver）
    dev_fd = open(DEVICE_PATH, O_RDONLY);
    if (dev_fd < 0) {
        perror("無法開啟 /dev/rc522");
        exit(1);
    }

    printf("開始讀取卡片...\n");

    while (1) {
        memset(uid_buf, 0, sizeof(uid_buf));
        ssize_t len = read(dev_fd, uid_buf, sizeof(uid_buf));
        if (len > 0) {
            // 成功讀到 UID，寫入 FIFO
            write(fifo_fd, uid_buf, strlen(uid_buf));
            printf("讀取到 UID: %s\n", uid_buf);
        }
        usleep(500000); // 500ms
    }

    close(dev_fd);
    close(fifo_fd);
    return 0;
}
