#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/spi/spi.h>
#include <linux/uaccess.h>

#define DEVICE_NAME "rc522"
#define CLASS_NAME  "rc522_class"

static int major;
static struct class *rc522_class;
static struct cdev rc522_cdev;
static struct spi_device *rc522_spi_device;

static int rc522_open(struct inode *inode, struct file *file) {
    return 0;
}

static int rc522_release(struct inode *inode, struct file *file) {
    return 0;
}

static ssize_t rc522_read(struct file *file, char __user *buf, size_t len, loff_t *offset) {
    uint8_t dummy_uid[4] = {0x83, 0xF1, 0x7C, 0x29};
    char uid_str[12]; // "83F17C29\n" + '\0'
    int str_len;

    // 只讀一次
    if (*offset > 0)
        return 0;

    // 轉成字串
    str_len = snprintf(uid_str, sizeof(uid_str), "%02X%02X%02X%02X\n",
                      dummy_uid[0], dummy_uid[1], dummy_uid[2], dummy_uid[3]);

    // 確保 buffer 足夠
    if (len < str_len)
        return -EINVAL;

    if (copy_to_user(buf, uid_str, str_len))
        return -EFAULT;

    *offset += str_len;
    return str_len;
}


static const struct file_operations rc522_fops = {
    .owner = THIS_MODULE,
    .open = rc522_open,
    .read = rc522_read,
    .release = rc522_release,
};

static int rc522_probe(struct spi_device *spi) {
    dev_t dev;
    int ret;

    rc522_spi_device = spi;

    ret = alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME);
    if (ret < 0)
        return ret;
    major = MAJOR(dev);

    cdev_init(&rc522_cdev, &rc522_fops);
    rc522_cdev.owner = THIS_MODULE;
    ret = cdev_add(&rc522_cdev, dev, 1);
    if (ret)
        goto unregister_chrdev;

    rc522_class = class_create(CLASS_NAME);
    if (IS_ERR(rc522_class)) {
        ret = PTR_ERR(rc522_class);
        goto del_cdev;
    }

    device_create(rc522_class, NULL, dev, NULL, DEVICE_NAME);
    return 0;

del_cdev:
    cdev_del(&rc522_cdev);
unregister_chrdev:
    unregister_chrdev_region(dev, 1);
    return ret;
}

static void rc522_remove(struct spi_device *spi) {
    device_destroy(rc522_class, MKDEV(major, 0));
    class_destroy(rc522_class);
    cdev_del(&rc522_cdev);
    unregister_chrdev_region(MKDEV(major, 0), 1);
}

static const struct of_device_id rc522_of_match[] = {
    { .compatible = "rfid,rc522" },
    { }
};
MODULE_DEVICE_TABLE(of, rc522_of_match);

static struct spi_driver rc522_driver = {
    .driver = {
        .name = DEVICE_NAME,
        .of_match_table = rc522_of_match,
    },
    .probe = rc522_probe,
    .remove = rc522_remove,
};

module_spi_driver(rc522_driver);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("c");
MODULE_DESCRIPTION("RC522 RFID Driver");
