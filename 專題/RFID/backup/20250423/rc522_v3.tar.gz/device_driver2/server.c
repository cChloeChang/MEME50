// server.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <wiringPi.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <microhttpd.h>

#define FIFO_PATH "/tmp/smart_lock_fifo"
#define HTTP_PORT 8080

// 授權 UID
const uint8_t authorized_uid[] = {0x83, 0xF1, 0x7C, 0x29};

fd_set readfds;
int fifo_fd;

// ========== HTTP 請求處理 ==========
static enum MHD_Result handle_request(void *cls, struct MHD_Connection *connection,
                                      const char *url, const char *method,
                                      const char *version, const char *upload_data,
                                      size_t *upload_data_size, void **con_cls) {
    struct MHD_Response *response;
    enum MHD_Result ret;
    char *response_str;

    if (strcmp(method, "GET") != 0) {
        response_str = strdup("方法不允許");
        response = MHD_create_response_from_buffer(strlen(response_str),
                                                   response_str, MHD_RESPMEM_MUST_FREE);
        ret = MHD_queue_response(connection, MHD_HTTP_METHOD_NOT_ALLOWED, response);
        MHD_destroy_response(response);
        return ret;
    }

    if (strcmp(url, "/unlock") == 0) {
        write(fifo_fd, "22", 2);  // 模擬授權卡
        response_str = strdup("開門命令已發送");
    } else if (strcmp(url, "/lock") == 0) {
        write(fifo_fd, "11", 2);  // 模擬未授權卡
        response_str = strdup("關門命令已發送");
    } else {
        response_str = strdup("未知命令");
    }

    response = MHD_create_response_from_buffer(strlen(response_str),
                                               response_str, MHD_RESPMEM_MUST_FREE);
    ret = MHD_queue_response(connection, MHD_HTTP_OK, response);
    MHD_destroy_response(response);
    return ret;
}

// ========== 主程式 ==========
int main(void) {
    int server_sockfd, client_sockfd;
    int server_len, client_len;
    struct sockaddr_in server_address;
    struct sockaddr_in client_address;
    int result;
    struct MHD_Daemon *daemon;

    // 開啟 FIFO 進行讀取
    printf("正在開啟 FIFO...\n");
    mkfifo(FIFO_PATH, 0666);
    fifo_fd = open(FIFO_PATH, O_RDONLY | O_NONBLOCK);
    if (fifo_fd < 0) {
        perror("無法開啟 FIFO");
        exit(1);
    }
    printf("FIFO 開啟成功\n");

    // 建立 socket
    server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    server_address.sin_port = htons(5090);
    server_len = sizeof(server_address);
    bind(server_sockfd, (struct sockaddr *)&server_address, server_len);
    listen(server_sockfd, 5);

    FD_ZERO(&readfds);
    FD_SET(server_sockfd, &readfds);
    FD_SET(fifo_fd, &readfds);

    // 啟動 HTTP server
    daemon = MHD_start_daemon(MHD_USE_SELECT_INTERNALLY, HTTP_PORT, NULL, NULL,
                              &handle_request, NULL, MHD_OPTION_END);
    if (!daemon) {
        perror("無法啟動 HTTP server");
        close(fifo_fd);
        exit(1);
    }
    printf("伺服器啟動完成，等待連線與 FIFO 輸入...\n");

    while (1) {
        char buffer[100];
        int fd;
        int nread;
        fd_set testfds = readfds;

        result = select(FD_SETSIZE, &testfds, NULL, NULL, NULL);
        if (result < 1) {
            perror("select");
            exit(1);
        }

        for (fd = 0; fd < FD_SETSIZE; fd++) {
            if (FD_ISSET(fd, &testfds)) {
                if (fd == server_sockfd) {
                    client_len = sizeof(client_address);
                    client_sockfd = accept(server_sockfd,
                                           (struct sockaddr *)&client_address,
                                           &client_len);
                    FD_SET(client_sockfd, &readfds);
                    printf("新 client 加入：fd %d\n", client_sockfd);
                } else if (fd == fifo_fd) {
                    memset(buffer, 0, sizeof(buffer));
                    nread = read(fifo_fd, buffer, sizeof(buffer)-1);
                    if (nread > 0) {
                        buffer[nread] = '\0';

                        // 判斷是否是 UID
                        if (nread == 8) {  // 例如 83F17C29
                            uint8_t uid[4];
                            sscanf(buffer, "%2hhx%2hhx%2hhx%2hhx", &uid[0], &uid[1], &uid[2], &uid[3]);

                            int is_authorized = memcmp(uid, authorized_uid, 4) == 0;
                            snprintf(buffer, sizeof(buffer), "%d", is_authorized ? 22 : 11);
                            printf("UID %02X%02X%02X%02X 授權結果: %s\n",
                                   uid[0], uid[1], uid[2], uid[3],
                                   is_authorized ? "授權" : "拒絕");
                        } else {
                            printf("從 FIFO 接收: %s\n", buffer);
                        }

                        // 廣播給所有 client
                        for (int i = 0; i < FD_SETSIZE; i++) {
                            if (i != server_sockfd && i != fifo_fd && FD_ISSET(i, &readfds)) {
                                char sendbuf[16];
                                snprintf(sendbuf, sizeof(sendbuf), "%s\n", buffer);
                                write(i, sendbuf, strlen(sendbuf));
                                printf("送出 %s 給 client fd %d\n", buffer, i);
                            }
                        }
                    }
                } else {
                    ioctl(fd, FIONREAD, &nread);
                    if (nread == 0) {
                        close(fd);
                        FD_CLR(fd, &readfds);
                        printf("client 離線：fd %d\n", fd);
                    } else {
                        memset(buffer, 0, sizeof(buffer));
                        read(fd, buffer, sizeof(buffer)-1);
                        printf("client 說：%s\n", buffer);
                    }
                }
            }
        }
    }

    close(fifo_fd);
    MHD_stop_daemon(daemon);
    return 0;
}

