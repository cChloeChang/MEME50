#include <linux/module.h>
#include <linux/spi/spi.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>

#define DEVICE_NAME "rc522"
#define CLASS_NAME "rc522_class"

static struct spi_device *rc522_spi_device;
static int major;
static struct class *rc522_class;
static struct cdev rc522_cdev;

// ---------- SPI 傳送函式 ----------
static int rc522_spi_transfer(uint8_t tx, uint8_t *rx) {
    struct spi_transfer t = {
        .tx_buf = &tx,
        .rx_buf = rx,
        .len = 1,
        .cs_change = 0,
    };
    struct spi_message m;
    spi_message_init(&m);
    spi_message_add_tail(&t, &m);
    return spi_sync(rc522_spi_device, &m);
}

// ---------- open ----------
static int rc522_open(struct inode *inode, struct file *file) {
    pr_info("rc522: open\n");
    return 0;
}

// ---------- read ----------
static ssize_t rc522_read(struct file *file, char __user *buf, size_t len, loff_t *offset) {
    uint8_t tx = 0x00; // example: command to read RC522 register 0x00
    uint8_t rx = 0;
    int ret = rc522_spi_transfer(tx, &rx);
    if (ret < 0) return ret;
    if (copy_to_user(buf, &rx, 1)) return -EFAULT;
    return 1;
}

// ---------- write ----------
static ssize_t rc522_write(struct file *file, const char __user *buf, size_t len, loff_t *offset) {
    uint8_t tx;
    if (copy_from_user(&tx, buf, 1)) return -EFAULT;
    return rc522_spi_transfer(tx, NULL);
}

// ---------- release ----------
static int rc522_release(struct inode *inode, struct file *file) {
    pr_info("rc522: release\n");
    return 0;
}

static const struct file_operations rc522_fops = {
    .owner = THIS_MODULE,
    .open = rc522_open,
    .read = rc522_read,
    .write = rc522_write,
    .release = rc522_release,
};

// ---------- SPI probe ----------
static int rc522_probe(struct spi_device *spi) {
    pr_info("rc522: probe\n");

    rc522_spi_device = spi;

    // 創建 char device
    major = register_chrdev(0, DEVICE_NAME, &rc522_fops);
    rc522_class = class_create(CLASS_NAME);
    device_create(rc522_class, NULL, MKDEV(major, 0), NULL, DEVICE_NAME);

    cdev_init(&rc522_cdev, &rc522_fops);
    cdev_add(&rc522_cdev, MKDEV(major, 0), 1);

    return 0;
}

// ---------- SPI remove ----------
static void rc522_remove(struct spi_device *spi) {
    pr_info("rc522: remove\n");

    device_destroy(rc522_class, MKDEV(major, 0));
    class_destroy(rc522_class);
    unregister_chrdev(major, DEVICE_NAME);
    cdev_del(&rc522_cdev);
}

// ---------- SPI device id ----------
static const struct of_device_id rc522_dt_ids[] = {
    { .compatible = "rfid,rc522" },
    { }
};
MODULE_DEVICE_TABLE(of, rc522_dt_ids);

// ---------- SPI driver ----------
static struct spi_driver rc522_driver = {
    .driver = {
        .name = "rc522",
        .of_match_table = rc522_dt_ids,
    },
    .probe = rc522_probe,
    .remove = rc522_remove,
};

module_spi_driver(rc522_driver);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Chloe");
MODULE_DESCRIPTION("RC522 SPI Driver (Device Tree)");
