#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x5ae685a1, "__spi_register_driver" },
	{ 0xe3d97303, "device_destroy" },
	{ 0xf4e1b5d, "class_destroy" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0x122c3a7e, "_printk" },
	{ 0xe1b2de7f, "driver_unregister" },
	{ 0xdcb764ad, "memset" },
	{ 0x328ac4f5, "spi_sync" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xf9a482f9, "msleep" },
	{ 0x6cbbfc54, "__arch_copy_to_user" },
	{ 0x5cf5454c, "__register_chrdev" },
	{ 0x1b58158e, "class_create" },
	{ 0xcc4889d4, "device_create" },
	{ 0x47e64c59, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "3133D8D0B7C57DBB36F48FE");
