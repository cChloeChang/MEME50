const express = require('express');
const path = require('path');
const { exec } = require('child_process');
const app = express();
const FIFO_PATH = '/tmp/smart_lock_fifo';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 路由
const router = require('./router');
app.use('/', router);

// 初始化FIFO
exec(`mkfifo ${FIFO_PATH}`, (err) => {
  if (err && err.code !== 1) console.error('FIFO初始化失敗:', err);
});

// 啟動伺服器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`伺服器運行在 http://localhost:${PORT}`);
});
