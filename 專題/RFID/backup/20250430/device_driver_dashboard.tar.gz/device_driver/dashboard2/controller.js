const fs = require('fs');
const FIFO_PATH = '/tmp/smart_lock_fifo';

// exports.doorControl = (req, res) => {
//   const cmd = req.body.command;
  
//   const data = cmd.toString(); // 將命令轉為字串
  
//   fs.writeFile(FIFO_PATH, data, (err) => {  // <-- 傳入字串
//     if (err) {
//       console.error('FIFO寫入失敗:', err);
//       return res.status(500).send('控制失敗');
//     }
//     res.send(`指令 ${data} 已發送`);
//   });
// };



// exports.doorControl = (req, res) => {
//   const cmd = req.body.command;
//   const data = cmd.toString();

//   // 開啟 FIFO 進行寫入
//   const fifo = fs.createWriteStream(FIFO_PATH, { flags: 'w' });

//   fifo.on('error', (err) => {
//     console.error('FIFO寫入失敗:', err);
//     return res.status(500).send('控制失敗');
//   });

//   fifo.write(data, (err) => {
//     if (err) {
//       console.error('FIFO寫入失敗:', err);
//       return res.status(500).send('控制失敗');
//     }
//     fifo.end(); // 寫完後才關閉
//     res.send(`指令 ${data} 已發送`);
//   });
// };


// 啟動時打開 FIFO（同步模式，保留 fd）
let fifoStream;

// 啟動時直接打開 FIFO（同步建立 WriteStream）
function openFIFO() {
  fifoStream = fs.createWriteStream(FIFO_PATH, { flags: 'w' });

  fifoStream.on('error', (err) => {
    console.error('FIFO開啟失敗:', err);
    process.exit(1); // 開啟失敗直接退出
  });

  fifoStream.on('open', () => {
    console.log('FIFO 開啟成功');
  });
}

openFIFO();

exports.doorControl = (req, res) => {
  const cmd = req.body.command;
  const data = cmd.toString();

  if (!fifoStream) {
    console.error('FIFO尚未開啟');
    return res.status(500).send('控制失敗');
  }

  fifoStream.write(data, (err) => {
    if (err) {
      console.error('FIFO寫入失敗:', err);
      return res.status(500).send('控制失敗');
    }
    res.send(`指令 ${data} 已發送`);
  });
};

// 關閉 FIFO
process.on('SIGINT', () => {
  console.log('關閉 FIFO...');
  if (fifoStream) {
    fifoStream.end(() => {
      console.log('FIFO已關閉');
      process.exit();
    });
  } else {
    process.exit();
  }
});