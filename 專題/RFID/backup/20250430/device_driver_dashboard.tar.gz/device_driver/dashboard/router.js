const express = require('express');
const router = express.Router();
const controller = require('./controller');

// API路由
router.post('/api/door', controller.doorControl);

// 前端路由
router.get('*all', (req, res) => {
    res.sendFile('index.html', { root: './public' });
});

module.exports = router;
