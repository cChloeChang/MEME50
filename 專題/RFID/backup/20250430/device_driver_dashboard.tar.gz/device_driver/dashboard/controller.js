const fs = require('fs');
const FIFO_PATH = '/tmp/smart_lock_fifo';

exports.doorControl = (req, res) => {
  const cmd = req.body.command;
  
  // 將命令轉為字串
  const data = cmd.toString();  // <-- 關鍵修正
  
  fs.writeFile(FIFO_PATH, data, (err) => {  // <-- 傳入字串
    if (err) {
      console.error('FIFO寫入失敗:', err);
      return res.status(500).send('控制失敗');
    }
    res.send(`指令 ${data} 已發送`);
  });
};